import uuid


print(uuid.uuid4().hex)
